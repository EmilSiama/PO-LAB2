package pl.siama.firstapp;

import java.util.Scanner;

public class Start {

    public static void main(String[] args) {

        public void Run(Scanner input) {
            System.out.println("Enter temperature 1:");
            int temp1 = input.nextInt();
            System.out.println("Enter temperature 2:");
            int temp2 = input.nextInt();

            System.out.println(this.compareTemperatures(temp1, temp2));
        }

        private boolean compareTemperatures (int temp1, int temp2) {
            if (temp1 < 100 || temp2 < 100) {
                return true;
            } else {
                return false;
            }

    }
}


